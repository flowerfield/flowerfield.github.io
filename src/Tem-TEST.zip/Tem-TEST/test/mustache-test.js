var fs = require("fs");
var expect = require("chai").expect;
var jsonfile = require("jsonfile");
var mustache = require("mustache");

describe("wendingding-mustache-test",function(){
    console.log(__dirname);
    var jsonFileFullPath = __dirname + "/../src/data.json";
    var templateFileFullPath = __dirname + "/../src/index.mustache";
    var targetFileFunllPath = __dirname + "/../src/index.html";

    it("JSON -> HTML",function(done){
        jsonfile.readFile(jsonFileFullPath,function(readJsonFileError,jsonData){
            if(!readJsonFileError)
            {
                fs.readFile(templateFileFullPath,"utf8",function(readTemplateFileError,templateData){
                    if(!readTemplateFileError)
                    {
                        var template = templateData.toString();
                        var html = mustache.render(template,jsonData);

                        fs.writeFile(targetFileFunllPath, html,  function(errorStatus) {
                            if (!errorStatus) {
                                console.log("转换成功并保存为HTML文件！");
                                done();
                            }else
                            {
                                done(errorStatus);
                            }  
                         }); 
                    }else
                    {
                        done(readTemplateFileError)
                    }
                })
            }else
            {
                done(readJsonFileError)
            }
        })
    })
})

